// Computer_class.cpp : main project file.

#include "stdafx.h"
#include "Form1.h"
#include "Splashform.h"

using namespace Computer_class;

[STAThreadAttribute]
int main(array<System::String ^> ^args)
{
	// Enabling Windows XP visual effects before any controls are created
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false); 

	// Create the main window and run it
	Application::Run(gcnew Splashform());
	Application::Run(gcnew Form1());
	return 0;
}
